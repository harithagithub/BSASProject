UserName : Suser
Password: password2015

IPV4 of Server VM = 192.168.178.48